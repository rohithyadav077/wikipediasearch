const form = document.getElementById("emailForm");
const successMsg = document.getElementById("successMsg");

if (form && successMsg) {
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    successMsg.style.display = "block";
    form.reset();
  });
}

